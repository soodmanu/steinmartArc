module.exports = {
  
  'http.commerce.catalog.storefront.products.getProduct.after': {
      actionName: 'http.commerce.catalog.storefront.products.getProduct.after',
      customFunction: require('./domains/commerce.catalog.storefront.products/http.commerce.catalog.storefront.products.getProduct.after')
  }
};
