module.exports = {
	PAYMENTSETTINGID : "PayPalExpress2",
	ENVIRONMENT: "environment",
	PAYPALENDPOINTURL: "Radial End point URL",
	PAYPALAPIKEY: "Radial Api Key",
	CAPTUREONSUBMIT: "AuthAndCaptureOnOrderPlacement",
	CAPTUREONSHIPMENT: "AuthOnOrderPlacementAndCaptureOnOrderShipment",
	FAILED: "Failed",
	NEW: "New",
	DECLINED: "Declined",
	AUTHORIZED: "Authorized",
	CAPTURED: "Captured",
	CREDITED: "Credited",
	CREDITPENDING: "CreditPending",
	VOIDED: "Voided"
};